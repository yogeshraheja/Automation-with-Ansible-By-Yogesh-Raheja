# This Repository contians all of the examples, tasks, playbooks, roles used to demonstrate Operations and Executions performed in the book "Automation with Ansible" by Yogesh Raheja.

# Author: Yogesh Raheja

# Skype: @yogeshraheja

# Mail: yogeshraheja07@gmail.com

# Phone: +91-9810344919

# Linkedin: linkedin.com/in/yogesh-raheja-b7503714

# Blogs: blog.thinknyx.com

# Blogs: unixadminschool.com/blog/author/yogesh-raheja

# Personal Blogs: yogeshraheja007.blogspot.com/
